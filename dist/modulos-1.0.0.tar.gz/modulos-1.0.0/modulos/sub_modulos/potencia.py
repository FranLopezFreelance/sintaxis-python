def potencia(base, exponente):
	print(base, "a la", exponente, "es:", base**exponente)
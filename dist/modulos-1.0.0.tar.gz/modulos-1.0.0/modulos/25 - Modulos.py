#Pueden ser archivos py, pyc (python compilado) o incluso de C para CPython
#Tienen su propio espacio de nombre
#Puede incluir variables, funciones, clases e incluso otros módulos
#Sirve para modularizar y reutilizar código

from funciones_matematicas import * #aqui indico que quiero que importe todo

sumar(2, 1)
restar(2, 1)
multiplicar(2, 1)
from setuptools import setup

setup(
    name="modulos",
    version="1.0.0",
    description="Prueba de Módulos",
    author="FJL",
    author_email="franlopez.freelance@gmail.com",
    packages=["modulos", "modulos.sub_modulos"]
)